import sys
print sys.argv
t=float(sys.argv[1])
print "Celcius=",((5.0/9)*(t-32))