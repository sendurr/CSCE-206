print "Lab 6 - Question 2"
print ""

import sys
F=float(sys.argv[1])
C=(F-32)*5.0/9
print "%.2f"%(C), "Degrees Celsius"

print ""
