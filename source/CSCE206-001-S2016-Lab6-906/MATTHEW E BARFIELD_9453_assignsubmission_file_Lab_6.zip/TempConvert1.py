
print "Lab 6 - Question 1"
print ""

Fahrenheit = int(raw_input("Enter a temperature in Fahrenheit: "))
Celsius = (Fahrenheit - 32) * 5.0/9.0
print "Temperature:", Fahrenheit, "Fahrenheit = ", Celsius, "C "

print ""