# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 18:01:00 2016

@author: Tret Burdette
"""

F=float(raw_input("please enter an temperature in Fahrenheit: "))
C= (F-32.0)*(5.0/9.0)

print "Temperature in Celsius=", C
