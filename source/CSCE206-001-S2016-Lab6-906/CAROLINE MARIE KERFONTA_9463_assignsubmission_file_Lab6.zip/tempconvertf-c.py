import sys
print (sys.argv)
x= float(sys.argv[1])
print (x)
c=(x-32)/(9/5)
print('input:',x, 'degree(F)')
print('output:',c, 'degree(C)')