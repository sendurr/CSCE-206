import sys
print (sys.argv)
x= float(sys.argv[1])
print (x)
c=(x-32)/(9/5)
print(c)


