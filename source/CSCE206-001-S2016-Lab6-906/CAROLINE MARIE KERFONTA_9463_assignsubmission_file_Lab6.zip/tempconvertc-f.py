import sys
print (sys.argv)
C= float(sys.argv[1])
print (C)
F = (9/5)*C-32
print('input:',C, 'degree(C)')
print('output:',F, 'degree(F)')