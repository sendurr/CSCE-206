F = float(raw_input("Input temperature in Fahrenheit: "))
C = (F-32)*5/9
print C