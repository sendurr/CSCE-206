F=int(input("What is the temperature in degrees Fahrenheit?"))
C=(F-32.0)*(float(5)/9.0)
print ("%.2f" %C)