# Jeremy Abrams
# CSCE 206
# Lab 6 - f2c_qa1.py
# February 11, 2016

fahrenheit = float(input("Enter a temperature in Fahrenheit: "))
celcius = (fahrenheit - 32)*(5/9)
print ("The temperature in Celcius is: ", celcius)