#1 
from math import *
F=eval(raw_input("What's the temp in F?"))
C=((F-32)/(9/5.0))
print("The temp is %s degrees in C"%(C))