import sys
#use sys.argv

print()

x=float(sys.argv[1]) #reads input from terminal

C = (x - 32) * (5./9)

print (x,'degrees Fahrenheit =', C , "degrees Celcius")
print()