import sys
Farhenheit = float(sys.argy[1])
Celcius = ((F-32)*(5.0/9))
print 'The temperature in Celcius is:'
print Celcius



