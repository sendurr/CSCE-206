print 'Enter Fahrenheit Temperature For Conversion to Celsius'
Fahrenheit = float(raw_input())
Celcius = ((F-32)*(5.0/9))
print Celcius


