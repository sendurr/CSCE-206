F=float(raw_input("temperature in Farenheit="))
C=(F-32)*5/9
print "temperature in Celcius=",C