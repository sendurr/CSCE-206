import sys
from math import *
print sys.argv
F=float(sys.argv[1])
# print F
C=(F-32)*5/9
print "Temperature in Celcius is", C