
temp=raw_input("What's the Temperature in Fahrenheit?")
print(temp)

import math

Fahrenheit = int(raw_input("What's the Temperature in Fahrenheit?: "))

Celsius = (Fahrenheit - 32) * 5.0/9.0
print "Temperature:", Fahrenheit, "Fahrenheit = ", Celsius, " C"

