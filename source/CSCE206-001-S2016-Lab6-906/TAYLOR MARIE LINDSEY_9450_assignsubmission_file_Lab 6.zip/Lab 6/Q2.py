
import sys

temperature=raw_input(C)

C = float(sys.argv[1])
F = 9.0*C/5 + 32
print F

Celsius = (F - 32) * 5.0/9.0
print "temperature:","Celsius="
