

import argparse

if tempconvert.py "--F", "100":
	else Celsius=(Fahrenheit - 32) * 5.0/9.0

print "Celsius="

if tempconvert.py "--C", "100":
	else Fahrenheit = 9.0*Celsius/5 + 32

print "Fahrenheit="