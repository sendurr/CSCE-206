#lab6_2
import sys
F=int(sys.argv[1])
C=(F-32)/1.8
print 'The temprature by Celsius is%.3f'%C