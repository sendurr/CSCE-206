#lab6_1
F=input('enter the temprature by Fehrenheit: ')
C=(F-32)/1.8
print 'The temprature by Celsius is %.3f'%C