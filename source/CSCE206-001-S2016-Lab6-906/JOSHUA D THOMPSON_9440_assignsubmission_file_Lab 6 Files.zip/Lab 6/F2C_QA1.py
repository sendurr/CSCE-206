# Question 1 for Lab 6

# The first stipulation is to make a program that reads and outputs conversions from fahrenheit to celsius

f=eval(raw_input("F = ?\n"))
print ("Input values", f)

c=float(5)/9*(-32+f)

print (c, "Celcius temperature Output")