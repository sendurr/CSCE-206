# Question 2: using sys.argv to run code that converts Farenheit to clesius temperatures given.


import sys #first step to using sys.argv
print sys.argv

f=float(sys.argv[1])

c=float(5)/9*(-32+F)

print ("Degrees Celcius", c)