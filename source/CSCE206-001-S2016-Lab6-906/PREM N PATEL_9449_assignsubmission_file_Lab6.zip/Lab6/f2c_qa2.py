import sys

F = float(sys.argv[1])
print "Fahrenheit = ", F
C = (F-32)*(5/9.0)
print "Celsius = ", C