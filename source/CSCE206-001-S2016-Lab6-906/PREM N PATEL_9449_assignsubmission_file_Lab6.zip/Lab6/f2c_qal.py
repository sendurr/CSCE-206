tempF = float(raw_input("Temp in Fahrenheit: "))
print "Fahrenheit = ", tempF

tempC = (tempF-32)*(5/9.0)
print "Celsius = ", tempC