F = eval(raw_input("F = ?\n"))
print ("input", F)

C = (F - 32)*float(5)/9

print (C, "Degrees Celcius")