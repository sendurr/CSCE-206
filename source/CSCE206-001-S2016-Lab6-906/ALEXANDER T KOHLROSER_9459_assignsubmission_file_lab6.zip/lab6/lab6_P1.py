#Begin Question 1
print "Question 1."

print "What temperature in Fahrenheit would you like to convert to Celsius?"

tempF = raw_input()

tempF = float(tempF)

tempC = (tempF-32)/1.8

print tempC
print ""
#End Question 1

#Begin Question 2
