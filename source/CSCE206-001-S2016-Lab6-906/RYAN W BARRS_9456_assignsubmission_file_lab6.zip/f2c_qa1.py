F = eval(raw_input("Temperature is how many degrees Fahrenheit?"))

C = (F-32)/(9/5.0)

print "This equals %s degrees Celsius" %(C)