# Name: Lucke Oliveira Luz         Assignment: Lab 6         Exercise: 2

import sys

F = sys.argv[1]
F = float(F)
C = (5/9.0)*(F - 32)
print "Temperature in Celsius is %.2f degrees"% (C)