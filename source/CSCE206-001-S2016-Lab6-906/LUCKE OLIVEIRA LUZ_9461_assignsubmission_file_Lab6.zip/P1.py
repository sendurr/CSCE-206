# Name: Lucke Oliveira Luz         Assignment: Lab 6         Exercise: 1

F = raw_input("Insert temperature in Fahrenheit: ")
F = float(F)
C = (5/9.0)*(F - 32)
print "Temperature in Celsius is %.2f degrees"% (C)