#lab6 Question 1
F=int(raw_input("what is the temperature in Fahrenheit?:"))
C=(F-32)*5.0/9
print "%.2f"%(C),"degrees Celsius"
