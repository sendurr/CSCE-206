import sys
print (sys.argv)
y= float(sys.argv[1])
print (y)
c=(y-32)/(9/5)
print(c)
