import sys
print (sys.argv)
F= float(sys.argv[1])
print (F)
c=(F-32)/(9/5)
print('input:',F, 'degree(F)')
print('output:',c, 'degree(C)')