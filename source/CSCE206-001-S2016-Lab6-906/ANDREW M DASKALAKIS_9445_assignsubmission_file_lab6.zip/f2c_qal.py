from math import *
########################
#	Q1
########################

Tf = raw_input("What is the Temperature in Fahrenheit: ")

Tc = (float(Tf)-32)*(5.0/9)

print "Temperature = %0.2f degrees Celsius" %(Tc) 

