t=raw_input("temperature in F:")
t=float(t)
C=(5.0/9.0)*(t-32.0)
print "Temperature in C", (C) 

