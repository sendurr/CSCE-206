#1.
from math import *
F = eval(raw_input("What is the temperature in Farenheit?"))

C = ((F-32)/(9/5.0))

print "The temperature is %s degrees in Celsius" %(C)