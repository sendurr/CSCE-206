import sys

print (sys.argv)

x=float(sys.argv[1])
temp=5/9*(x-32)

print (temp)

