F=float(input("What is the temperature in Farenheit?"))
temperature=5/9*(F-32)
print ("temperature:",temperature)