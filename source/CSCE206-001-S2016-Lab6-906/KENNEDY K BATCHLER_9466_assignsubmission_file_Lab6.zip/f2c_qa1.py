F=float(input('Enter degree Fahrenheit'))
celcius=(F-32)*5/9

print celcius