F = float(raw_input('Temperature in Fahrenheit'))
C = (F-32.)*(5./9.)
print float(C)