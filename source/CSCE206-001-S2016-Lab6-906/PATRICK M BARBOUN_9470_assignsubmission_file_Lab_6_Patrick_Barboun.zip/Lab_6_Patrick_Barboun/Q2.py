import sys as sys

F = float(sys.argv[1])
C = (F-32.)*5/9

print C
