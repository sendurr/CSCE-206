infile = open("votes.csv", 'r')
 
lines = infile.readlines()

a=[]

print a

for x in lines:
	items=x.split(",")

for x in lines:
	if x == "bill"
	return "bill: ",x
for y in lines:
	if y == "john: ",y
	return y
for z in lines:
	if z == "carol"
	return "carol: ",z

	#I could not get Python to open a .txt file for whatever reason, so I used a .csv file.