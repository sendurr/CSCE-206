# -*- coding: utf-8 -*-
"""
Created on Wed Mar 02 16:55:06 2016

@author: Tret Burdette
"""

infile=open("votes.txt",'r')
lines=infile.readlines()
skips=0
votes=0
votes1=0
votes2=0
votes3=0
votes4=0

for x in lines:
#    if x=="\n" or x[0]=="#":
#		skips+=1
#		continue
    items=x.strip().split(",")
    print items
    for item in items:
        if item.strip()=='John':
            votes+=1
        elif item.strip()=='Jimmy':
            votes1+=1
        elif item.strip()=='Lilly':
            votes2+=1
        elif item.strip()=='Joseph':
            votes3+=1
        elif item.strip()=='Linda':
            votes4+=1



print 'John', votes
print 'Jimmy', votes1
print 'Lilly', votes2
print 'Joseph', votes3
print 'Linda', votes4