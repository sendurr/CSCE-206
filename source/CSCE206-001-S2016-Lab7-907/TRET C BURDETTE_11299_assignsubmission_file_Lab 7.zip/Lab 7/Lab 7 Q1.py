# -*- coding: utf-8 -*-
"""
Created on Wed Mar 02 16:32:49 2016

@author: Tret Burdette
"""

import sys
print sys.argv

x= float(sys.argv[2])

y=float(sys.argv[3])

op=sys.argv[1]
print x,op,y,'=',

if op == "*":
	print x*y
elif op =="-":
	print x-y
elif op == "+":
	print x+y
elif op == "/":
	if y==0:
		print "error: denominator cannot be 0."
	else:
		print x/y
