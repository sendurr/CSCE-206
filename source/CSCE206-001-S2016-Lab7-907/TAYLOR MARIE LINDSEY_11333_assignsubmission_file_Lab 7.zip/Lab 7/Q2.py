
import vote.txt

d={"john":3,"jimmy":1,"lilly":1,"joseph":1,"linda":2}
print d

d={"john":25,"lilly":15,"linda":10}
print d