#1-----------------------------
import sys
# op=sys.argv[1]
# x=float(sys.argv[2])
# y=float(sys.argv[3])
# if op == "*":
# 	print (x,"*",y,"=",x*y)
# elif op =="-":
# 	print (x,"-",y,"=",x-y)
# elif op == "+":
# 	print (x,"+",y,"=",x+y)
# elif op == "/":
# 	if y==0:
# 		print ("error: denominator cannot be zero")
# 	else:
# 		print (x,"/",y,"=",x/y)
#2-----------------------------
import operator
infile=open("votes.txt","r")
lines=infile.readlines()
infile.close()

votecount={}

for line in lines:
	votes=line.strip().split(",")
	for vote in votes:
		try:
			votecount[vote.strip()]+=1

		except:
				votecount[vote.strip()]=1
print (votecount)
sorted_votecount=sorted(votecount.items(),key=operator.itemgetter(1),reverse=True)
for x in sorted_votecount:
	print(x[0],"\t",x[1])
