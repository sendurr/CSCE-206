import sys
valid = True
operator = sys.argv[1]

num1 = sys.argv[2]

num2 = sys.argv[3]
 
result = 0
if operator == "+":
	result = int(num1) + int(num2)
elif operator == "-":
	result = int(num1) - int(num2)
elif operator == "*":
	result = int(num1) * int(num2)
elif operator == "/":
	if int(num2) == 0:
		print "Denominator cannot be 0"
		valid = False
	else:
		result = int(num1) / int(num2)
else:
	print "Command not valid"
if valid:
	print (num1, " ", operator, " ", num2, "is equal to: ", result)