# Josh Thompson Lab 3 Assignment

# Question 1

L1= set([2, 3, 4,10])
L2= set([5,3,4,9,10,15])

print set.intersection(L1,L2)

print set.symmetric_difference(L1,L2)

print set.difference(L1,L2)

L3 = set.union(L1,L2)

print L3

#########################################

L1=[2, 3, 4,10]
L2=[5,3,4,9,10,15]

L2.append(304)
L2.append(20)
L2.append(34)
print "Updated List:", L2

##########################################

list1 = range(13,1000,2)

sum_list = sum(list1)

print sum_list

############################################


import random
x=[int(300*random.random()) for i in xrange(300)]

while x <

# I honestly do not how to do the final problem, so I won't waste your time while grading



