# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 21:52:28 2016

@author: Tret Burdette
"""


class Sum:
    def __init__(term,M,N):
        term.M=k
        term.N=N
    def term(k,x):
        if term.M > term.N:
            return (-x)**k
            M+=1
        else:
            break

S=Sum(term,M=0,N=100)
x=0.5
print S(x)

def first_neglected_term:
    return (-x)**(term.N)

print S.first_neglected_term
