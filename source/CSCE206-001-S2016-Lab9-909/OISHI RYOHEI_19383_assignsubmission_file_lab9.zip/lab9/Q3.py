# Q3
class Sum:
	def __init__(self, )