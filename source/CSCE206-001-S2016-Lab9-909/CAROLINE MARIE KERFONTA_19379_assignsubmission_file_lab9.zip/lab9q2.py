s1 = Simple(4)
for i in range(4):
	s1.double()
print (s1.i)

s2 = Simple('Hello')
s2.double(); s2.double()
print s2.1
s2.1 = 100
print (s2.i)
