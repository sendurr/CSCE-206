#f2c_qa1
F=float(raw_input())
C=(F-32)*(5.0/9)
print ("Please enter a temperature in degrees Farenheit")
print (C)

#f2c_qa2
import sys
F=float(sys.argv[1])
C=(F-32)*(5.0/9)
print ("The Temperature in Celcius is:", C)