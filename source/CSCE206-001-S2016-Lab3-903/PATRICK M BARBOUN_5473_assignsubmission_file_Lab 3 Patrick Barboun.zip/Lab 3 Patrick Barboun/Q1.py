L1 = set([2,3,4,10])
L2 = set([5,3,4,9,10,15])	#Defined my lists

print L1&L2
print L1^L2					#Printed the various values asked for
print L1-L2
L3 = list(L1)+list(L2)		#Combined sets
add = [103,20,34]
L3.append(add)				#Add a new values to the combined list