a = [13]

while a[-1]!=999:
	a.append(a[-1]+1)
variable_sum = sum(a[0::2])
print variable_sum


