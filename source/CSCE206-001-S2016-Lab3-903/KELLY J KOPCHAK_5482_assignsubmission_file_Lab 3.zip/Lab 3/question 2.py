sum1=0
A=13
stepsize=2
while A<1000:
	sum1+=A
	A+=stepsize
print sum1
	
