# Name: Lucke Oliveira Luz		Assignment: Lab 3      Exercise: 2

n = 13
SUM = []
while n <= 999:
	SUM.append(n)
	n = n+2
print "SUM =", SUM