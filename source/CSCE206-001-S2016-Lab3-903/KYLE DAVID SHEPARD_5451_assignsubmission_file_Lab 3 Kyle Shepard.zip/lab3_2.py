c=range(13,1000,2)

print sum(c)