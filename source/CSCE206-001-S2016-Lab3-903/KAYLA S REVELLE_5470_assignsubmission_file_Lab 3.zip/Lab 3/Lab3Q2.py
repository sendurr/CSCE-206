
sum_=0
i = 13


while i <= 999:
	sum_ += i
	i += 2
print(sum_)