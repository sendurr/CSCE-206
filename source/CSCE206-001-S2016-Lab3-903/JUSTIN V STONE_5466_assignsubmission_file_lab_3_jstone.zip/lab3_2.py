varSum = 0
num = 13
while num < 999:
	varSum += num
	num += 2
print "varSum:", varSum