L1=set([2,3,4,10])
L2=set([5,3,4,9,10,15])
print (L1).intersection(L2) #numbers that exist in L1 and L2
