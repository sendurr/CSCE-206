L1=set([2,3,4,10])
L2=set([5,3,4,9,10,15])
Q1pt5=list(L1|L2)
Q1pt5.append(103),Q1pt5.append(20),Q1pt5.append(34)
print Q1pt5 #appended L1