L1=set([2,3,4,10])
L2=set([5,3,4,9,10,15])
print L2.difference(L1)   #what appears in L2 but NOT L1