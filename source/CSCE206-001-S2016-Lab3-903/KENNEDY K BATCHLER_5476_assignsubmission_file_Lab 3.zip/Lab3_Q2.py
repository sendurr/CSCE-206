sum = 0
q2 = 13
while q2 <= 999:
    q2 = q2 + 2
    sum = sum + q2
print (sum)