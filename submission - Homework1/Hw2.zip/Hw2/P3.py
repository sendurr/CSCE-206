dx = 0.01
h = 0.01
coord = []
for i in range(0,101):
	x = 1+ i*h
	coord.append(x)
print coord